# Simple Calculator

This is a simple command-line calculator written in Python. It supports addition, subtraction, multiplication, and division.

## How to Use

1. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/Simple-Calculator.git
   ```
2. Navigate into the project directory:
   ```bash
   cd Simple-Calculator
   ```
3. Run the script:
   ```bash
   python calculator.py
   ```

## Example

```bash
Enter first number: 10
Enter operator (+, -, *, /): *
Enter second number: 5
Result: 50
```

## License

This project is licensed under the MIT License.
